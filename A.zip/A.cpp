#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <list>
#include <set>
#include <fstream>
#include <functional>
#include <climits>
#include <experimental/filesystem>

namespace fs = std::experimental::filesystem::v1;
using namespace std;

const bool DEBUG = 1;
const int shingleSize = 2 ;

map<int,vector<string> > docsInfo;
map<int, set<string> > docsAsShingleSets_String;
map<int, set<int> > docsAsShingleSets;
set<int> docNames;

vector<string> split(const string& s, char delimiter)
{
	vector<string> tokens;
	string token;
	istringstream tokenStream(s);
	while (getline(tokenStream, token, delimiter))
	{
                if(token.size() > 0 &&  token != " "){
                        token.erase(remove(token.begin(), token.end(), ' '), token.end());
			tokens.push_back(token);     
		} 
	}
	return tokens;
}

void llegirDocuments(){
	string path = "./docs";
	int id = 0;
	docNames.clear();
	for (const auto & entry : fs::directory_iterator(path)){
		docNames.insert(id);

		ifstream t(entry.path());
		string str;

		t.seekg(0, t.end);   
		str.reserve(t.tellg());
		t.seekg(0, t.beg);

		str.assign((istreambuf_iterator<char>(t)),istreambuf_iterator<char>()); //read document as string
		str.erase(remove(str.begin(), str.end(), '\n'), str.end());
		str.erase(remove(str.begin(), str.end(), '\r'), str.end());

		docsInfo[id] = split(str , ' ');		

                if(DEBUG){
                        cout << "Document " <<  id << " has all this words: " << endl;
                        for(int j = 0; j < docsInfo[id].size(); j++){
                                cout << docsInfo[id][j] <<  endl;
                        }
                        cout << endl << endl;
                }
		id++;
	}
}

void convertirShingles(){
	for(int i= 0; i < docNames.size(); i++){
		for(int k =0 ; k < docsInfo[i].size(); k++){
			if(k+shingleSize <= docsInfo[i].size()){			
				string shingle = "";
				for(int j=0; j < shingleSize; j++){
					if(j != 0 ) shingle += " ";
					shingle += docsInfo[i][k+j];
				}
				docsAsShingleSets_String[i].insert(shingle);//string shingle

                                hash<std::string> hasher;
                                unsigned long hashed = hasher(shingle);
                                int abbreviated_hash = hashed & INT_MAX;
                                docsAsShingleSets[i].insert(abbreviated_hash);//int hashed shingle
			}
		}	

                if(DEBUG){
                        cout << "Document " <<  i << " has all this shingles: " << endl;
                        for(auto f : docsAsShingleSets_String[i]) {
                                cout << f << endl;
                        } 
                        cout << endl << endl;
                }
	}
}

int main()
{
	llegirDocuments();
	convertirShingles();
}